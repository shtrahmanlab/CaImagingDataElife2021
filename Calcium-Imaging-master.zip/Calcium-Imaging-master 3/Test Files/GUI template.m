function [ output_args ] = GUI template( input_args )
%GUI TEMPLATE Summary of this function goes here
%   Detailed explanation goes here


end


# Calcium-Imaging
This software takes in a .tiff file from calcium imaging mice. It also requires a .mat file of the running data. It will correct for motion in the movie, segment to find cells, and analysis on each active cell.
